#!/bin/bash
# Rotates portrait images (only) in the current folder
# From ArtEvolver Tutorial in The MagPi - by Sean McManus

mkdir original_images

# Remove any extensions in the list below that you're not using to avoid error messages
for image_file in *.jpg *.JPG *.png *.PNG;
do
# Make sure there is no space around the = below
    width=$(identify -format "%w" $image_file)
    height=$(identify -format "%h" $image_file)
    if test $height -gt $width
    then
        echo "$image_file is portrait shape [$width x $height]. Rotating..."
        new_name="rotated-${image_file}"
        convert -rotate 90 "$image_file" "$new_name"
        mv $image_file original_images
    else
        echo "$image_file is landscape already [$width x $height]."
    fi
done